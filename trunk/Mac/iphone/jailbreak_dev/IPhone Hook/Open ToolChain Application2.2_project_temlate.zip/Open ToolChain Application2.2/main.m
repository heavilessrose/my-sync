//
//  main.m
//  ___PROJECTNAME___
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "___PROJECTNAMEASIDENTIFIER___App.h"

int main(int argc, char *argv[])
{
	int returnCode;
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    returnCode = UIApplicationMain(argc, argv, @"___PROJECTNAMEASIDENTIFIER___App", @"___PROJECTNAMEASIDENTIFIER___App");
    [pool release];
    return returnCode;
}
