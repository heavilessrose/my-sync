/*
 *  ExampleHookLibrary.h
 *  
 *
 *  Created by John on 10/4/08.
 *  Copyright 2008 Gojohnnyboi. All rights reserved.
 *
 */


#import "ExampleHookProtocol.h"

// Our method to override the launch of the icon
static void __$ExampleHook_AppIcon_Launch(SBApplicationIcon<ExampleHook> *_SBApplicationIcon);

// Our intiialization point that will be called when the dylib is loaded
extern "C" void ExampleHookInitialize();