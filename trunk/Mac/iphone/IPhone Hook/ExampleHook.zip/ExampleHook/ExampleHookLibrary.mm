/*
 *  ExampleHookLibrary.mm
 *  
 *
 *  Created by John on 10/4/08.
 *  Copyright 2008 Gojohnnyboi. All rights reserved.
 *
 */


#import "ExampleHookLibrary.h"

static void __$ExampleHook_AppIcon_Launch(SBApplicationIcon<ExampleHook> *_SBApplicationIcon) {
	
	UIAlertView* __launchView = [[UIAlertView alloc] init];
	__launchView.title = @"No way muchacho";
	__launchView.message = @"You can't touch dis!";
	[__launchView addButtonWithTitle:@"Dismiss"];
	[__launchView show];
	
	// If at any point we wanted to have it actually launch we should do:
	// [_SBApplicationIcon __OriginalMethodPrefix_launch];
}

extern "C" void ExampleHookInitialize() {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	// Get the SBApplicationIcon class
	Class _$SBAppIcon = objc_getClass("SBApplicationIcon");
	
	// MSHookMessage is what we use to redirect the methods to our own
	MSHookMessage(_$SBAppIcon, @selector(launch), (IMP) &__$ExampleHook_AppIcon_Launch, "__OriginalMethodPrefix_");
	
	// We just redirected SBApplicationIcon's "launch" to our custom method, and now we are done.
	
	[pool release];
}