/*
 * Copyright (C) 2007-2008 Geometer Plus <contact@geometerplus.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */

package org.geometerplus.zlibrary.ui.android.dialogs;

import java.util.ArrayList;

import android.content.Context;
import android.view.*;
import android.widget.*;

import org.geometerplus.zlibrary.core.resources.ZLResource;
import org.geometerplus.zlibrary.core.dialogs.*;
import org.geometerplus.zlibrary.core.util.ZLArrayUtils;

class ZLAndroidDialogContent extends ZLDialogContent {
	private Context myContext;
	protected ListView myListView;

	final ArrayList myAndroidViews = new ArrayList();
	private boolean[] mySelectableMarks = new boolean[10];

	ZLAndroidDialogContent(Context context, ZLResource resource) {
		super(resource);
		myContext = context;
	}

	protected void createListView(Context context) {
		myContext = context;
		myListView = new ListView(context);	
		myListView.setAdapter(new ViewAdapter());
	}

	Context getContext() {
		return myContext;
	}

	private ArrayList getAndroidViews() {
		if (myAndroidViews.isEmpty()) {
			final ArrayList views = Views;
			final int len = views.size();
			for (int i = 0; i < len; ++i) {
				final ZLAndroidOptionView v = (ZLAndroidOptionView)views.get(i);
				if (v.isVisible()) {
					v.addAndroidViews();	
				}
			}
		}
		return myAndroidViews;
	}

	void invalidateView() {
		if (!myAndroidViews.isEmpty()) {
			myAndroidViews.clear();
			myListView.setAdapter(new ViewAdapter());
			myListView.invalidate();
		}
	}

	public void addOptionByName(String name, ZLOptionEntry option) {
		if (name != null) {
			name = name.replaceAll("&", "");
		}
		ZLAndroidOptionView view = null;
		switch (option.getKind()) {
			case ZLOptionKind.BOOLEAN:
				view = new ZLAndroidBooleanOptionView(
					this, name, (ZLBooleanOptionEntry)option
				);
				break;
			case ZLOptionKind.BOOLEAN3:
				view = new ZLAndroidBoolean3OptionView(
					this, name, (ZLBoolean3OptionEntry)option
				);
				break;
			case ZLOptionKind.STRING:
				view = new ZLAndroidStringOptionView(
					this, name, (ZLStringOptionEntry)option
				);
				break;
			case ZLOptionKind.CHOICE:
				view = new ZLAndroidChoiceOptionView(
					this, name, (ZLChoiceOptionEntry)option
				);
				break;
			case ZLOptionKind.SPIN:
				view = new ZLAndroidSpinOptionView(
					this, name, (ZLSpinOptionEntry)option
				);
				break;
			case ZLOptionKind.COMBO:
				view = new ZLAndroidComboOptionView(
					this, name, (ZLComboOptionEntry)option
				);
				break;
			case ZLOptionKind.COLOR:
				view = new ZLAndroidColorOptionView(
					this, name, (ZLColorOptionEntry)option
				);
				break;
			case ZLOptionKind.KEY:
				view = new ZLAndroidKeyOptionView(
					this, name, (ZLKeyOptionEntry)option
				);
				break;
			case ZLOptionKind.ORDER:
				// TODO: implement
				break;
			case ZLOptionKind.MULTILINE:
				// TODO: implement
				break;
		}
		if (view != null) {
			view.setVisible(option.isVisible());
		}
		addView(view);
	}

	public void addOptionsByNames(String name0, ZLOptionEntry option0, String name1, ZLOptionEntry option1) {
		if (option0 != null) {
			addOptionByName(name0, option0);
		}
		if (option1 != null) {
			addOptionByName(name1, option1);
		}
	}

	void addAndroidView(View view, boolean isSelectable) {
		if (view != null) {
			boolean[] marks = mySelectableMarks;
			final int len = marks.length;
			final int index = myAndroidViews.size();
			if (index == len) {
				marks = ZLArrayUtils.createCopy(marks, len, 2 * len);
				mySelectableMarks = marks;
			}
			myAndroidViews.add(view);
			marks[index] = isSelectable;
		}
	}

	private class ViewAdapter extends BaseAdapter {
		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = (View)getAndroidViews().get(position);
			}

			return convertView;
		}

		public boolean areAllItemsSelectable() {
			return true;
		}

		public boolean isSelectable(int position) {
			return mySelectableMarks[position];
		}

		public int getCount() {
			return getAndroidViews().size();
		}

		public Object getItem(int position) {
			return "";
		}

		public long getItemId(int position) {
			return position;
		}
	}
}
