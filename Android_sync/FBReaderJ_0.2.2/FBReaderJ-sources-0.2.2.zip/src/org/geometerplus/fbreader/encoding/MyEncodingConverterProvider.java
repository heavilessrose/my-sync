package org.geometerplus.fbreader.encoding;

public class MyEncodingConverterProvider extends ZLEncodingConverterProvider {

	public ZLEncodingConverter createConverter(String encoding) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean providesConverter(String encoding) {
		// TODO Auto-generated method stub
		return false;
	}

}
